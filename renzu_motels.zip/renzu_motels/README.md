# renzu_motels
Fivem - Motel Management. Hourly Rental System. Supports MLO and Shells. ESX/QBCORE

![image](https://user-images.githubusercontent.com/82306584/226111405-b162c926-6c00-4085-91ac-839f7ece117e.png)

# Features
- Player Motel Business Management (change hour rates, hire employees, add / kick occupants)
- Hourly Rental System
- Configurable Maximum Occupants per room
- Configurable Sharable Room Stash (stealable) or Unique per Players
- Police can Break in using Gunshot in doors.
- Lockpickable Doors
- Supports MLO / Shells
- Supports Multiple Skin resource for Wardrobes.
- Support Targets or Zone Markers
- Support Metadata item Keys Sharing

# Dependency
- ox_lib
- ESX / QBCORE
- ox_inventory / qb-inventory
- ox_target / qb-target (optional)

# Item name
- keys

# Todo
```
some features im looking to add later like Job Owneds
```
